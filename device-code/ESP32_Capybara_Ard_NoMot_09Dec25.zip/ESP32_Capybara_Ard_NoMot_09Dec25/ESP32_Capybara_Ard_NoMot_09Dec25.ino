// ESP32_Node_LVGL.ino
// NODE Hybrid Mode: Screen + BLE Active, Buttons/Motor/Buzzer Disabled
#define NODE_HARDWARE_DISABLED 1

#include <Arduino.h>
#include "lvgl.h"
#include "esp_task_wdt.h"

#include "Wireless.h"
#include "RTC_PCF85063.h"
#include "SD_Card.h"
#include "LVGL_Driver.h"
#include "BAT_Driver.h"
#include "Simulated_Gesture.h"
#include "Node_Core.h"


void Driver_Init()
{
    Serial.println("[SYSTEM] Driver_Init()");

    // ---- REQUIRED FOR LCD + SD ----
    Serial.println("[SYSTEM] I2C_Init()");
    I2C_Init();

    Serial.println("[SYSTEM] TCA9554PWR_Init()");
    TCA9554PWR_Init(0x00);

    Serial.println("[SYSTEM] Set_EXIO(EXIO_PIN8,Low)");
    Set_EXIO(EXIO_PIN8, Low);

    Serial.println("[SYSTEM] LCD power/reset settle delay");
    delay(120);

    Serial.println("[SYSTEM] LCD_Init()");
    LCD_Init();

    Serial.println("[SYSTEM] Backlight_Init()");
    Backlight_Init();
    Set_Backlight(100);

    Serial.println("[SYSTEM] SD_Init()");
    SD_Init();


    // ---- HYBRID MODE CHECK ----
#if NODE_HARDWARE_DISABLED == 1
    Serial.println("[HYBRID] Hardware drivers disabled (RTC/IMU/BAT skipped).");
    return;     // <-- EXIT NOW, LCD + SD already initialized
#endif


    // ---- FULL HARDWARE MODE ONLY ----
    Serial.println("[SYSTEM] Flash_test()");
    Flash_test();

    Serial.println("[SYSTEM] BAT_Init()");
    BAT_Init();

    Serial.println("[SYSTEM] PCF85063_Init()");
    PCF85063_Init();

    Serial.println("[SYSTEM] QMI8658_Init()");
    QMI8658_Init();
}


void Driver_Loop(void *parameter)
{
    // Remove this task from the watchdog so it never causes errors
    esp_task_wdt_delete(NULL);

    // Print very rarely
    const TickType_t sleepTicks = pdMS_TO_TICKS(50);   // small, cooperative sleep
    uint32_t lastPrint = 0;

    while (1) {
        // Only print once every 5 seconds (or turn it off entirely)
        if (millis() - lastPrint > 5000) {
            Serial.println("[HARDWARE DISABLED] Driver_Loop idle");
            lastPrint = millis();
        }

        // Let other tasks (LVGL, WiFi, BLE) run smoothly
        vTaskDelay(sleepTicks);
    }
}


void setup()
{
    Serial.begin(115200);
    delay(300);

    Serial.println("\n===============================");
    Serial.println("NODE Hybrid Mode Startup");
    Serial.println("Screen + BLE Active");
    Serial.println("Buttons + Motor + Buzzer Disabled");
    Serial.println("===============================");

    Driver_Init();

    Serial.println("[SYSTEM] Lvgl_Init()");
    Lvgl_Init();

    // Initialize LVGL + BLE + timers
    Node_Core_Init();

    // No touch hardware → stay
    Simulated_Touch_Init();

    // Background task
    xTaskCreatePinnedToCore(
        Driver_Loop,
        "Driver Loop",
        4096,
        NULL,
        1,
        NULL,
        0
    );
}

void loop()
{
    // LVGL rendering
    Lvgl_Loop();

    // NODE brain loop
    Node_Core_Loop();

    vTaskDelay(pdMS_TO_TICKS(5));

}
