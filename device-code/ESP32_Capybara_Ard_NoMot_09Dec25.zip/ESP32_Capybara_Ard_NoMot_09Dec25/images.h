#ifndef IMAGES_H
#define IMAGES_H

#include <stdint.h>

// Image dimensions
#define NODE_LOGO_WIDTH 150
#define NODE_LOGO_HEIGHT 80
extern const uint16_t node_logo[12000];

#define CAPYBARA_FRAME1_WIDTH 180
#define CAPYBARA_FRAME1_HEIGHT 180
extern const uint16_t capybara_frame1[32400];

#define CAPYBARA_FRAME2_WIDTH 180
#define CAPYBARA_FRAME2_HEIGHT 180
extern const uint16_t capybara_frame2[32400];

#define CAPYBARA_FRAME3_WIDTH 180
#define CAPYBARA_FRAME3_HEIGHT 180
extern const uint16_t capybara_frame3[32400];

#define CAPYBARA_FRAME4_WIDTH 180
#define CAPYBARA_FRAME4_HEIGHT 180
extern const uint16_t capybara_frame4[32400];


#endif // IMAGES_H
