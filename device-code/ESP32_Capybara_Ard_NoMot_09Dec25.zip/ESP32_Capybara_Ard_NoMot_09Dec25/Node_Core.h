// Node_Core.h
#pragma once

void Node_Core_Init();
void Node_Core_Loop();
