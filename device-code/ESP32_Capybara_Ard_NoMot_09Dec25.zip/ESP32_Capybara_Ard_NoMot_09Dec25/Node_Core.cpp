#define FRAME_W 180
#define FRAME_H 180
#define FRAME_SIZE (FRAME_W * FRAME_H * 2)
#define FRAME_COUNT 150   // or however many .bin frames you exported

#define DISP_W 270
#define DISP_H 270

// Enable this when you want to run without BLE
#define NODE_TEST_CONFIG_ON_BOOT 1


#include "Node_Core.h"
#include <Arduino.h>
#include <vector>
#include <FS.h>
#include <SPIFFS.h>
#include <TimeLib.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#include "lvgl.h"
#include "images.h"
#include "SD_MMC.h"

// ==============================
// GLOBALS
// ==============================

// Forward Declarations
static void createTestFile();
static void parseFile(const char *name);
static void ensureConfigFileExistsAndParse();

// LVGL
static lv_obj_t *ui_label = nullptr;
static lv_color_t *canvas_buf;
static lv_obj_t *canvas = nullptr;
static bool canvas_ready = false;

// Static image buffers in internal RAM ---
static lv_color_t node_buf[NODE_LOGO_WIDTH * NODE_LOGO_HEIGHT];
static lv_color_t capy_buf[CAPYBARA_FRAME1_WIDTH * CAPYBARA_FRAME1_HEIGHT];

// BLE
static BLECharacteristic *pCharacteristic = nullptr;
bool deviceConnected = false;

// Incoming BLE buffer
static String incomingData;

// Reminder / time
static time_t currentTime = 0;    // "Current Time" from file
static time_t reminderTime = 0;   // Absolute reminder time (Unix)
static bool   reminderPending = false;
static bool   inPromptFlow = false;

// Parsed data
static std::vector<String> prompts;
static std::vector<String> options;

// Extra metadata (not yet used on UI but parsed & stored)
static String medicationName;
static String doseStr;
static String frequencyStr;

// set in BLE callback, handled in Node_Core_Loop
static bool configFileReady = false;   


// ==============================
// UTILS: TIME / FILE
// ==============================

// Format: "YYYY-MM-DD HH:MM:SS"
static String getFormattedDateTime() {
    char buffer[20];
    snprintf(
        buffer,
        sizeof(buffer),
        "%04d-%02d-%02d %02d:%02d:%02d",
        year(), month(), day(), hour(), minute(), second()
    );
    return String(buffer);
}

static void deleteFile(const char *file_name) {
    if (SPIFFS.exists(file_name)) {
        if (SPIFFS.remove(file_name)) {
            Serial.printf("[SPIFFS] Deleted %s\n", file_name);
        } else {
            Serial.printf("[SPIFFS] Failed to delete %s\n", file_name);
        }
    }
}

// Save the *incoming configuration file* (replaces /received.txt)
static void saveToFile(String data, const char *file_name) {
    data.replace("EOF", "");   // strip EOF marker

    // Replace old config file
    deleteFile(file_name);

    File file = SPIFFS.open(file_name, "w");
    if (!file) {
        Serial.printf("[SPIFFS] Failed to open %s for writing\n", file_name);
        return;
    }

    String dt = getFormattedDateTime();
    file.println("Date: " + dt);  // add header line
    file.print(data);             // raw file content from app
    file.close();

    Serial.printf("[SPIFFS] Wrote %s with date header\n", file_name);
}

// Append data to a log file (like old saveData)
static void saveData(const String &data, const char *file_name) {
    String cleaned = data;
    cleaned.replace("EOF", "");

    File file = SPIFFS.open(file_name, "a");   // append
    if (!file) {
        Serial.printf("[SPIFFS] Failed to open %s for appending\n", file_name);
        return;
    }

    // If this is a medication event, prepend a Date line
    if (cleaned.indexOf("Medication Taken:") != -1) {
        String dt = getFormattedDateTime();
        file.println("Date: " + dt);
    }

    file.println(cleaned);
    file.close();

    Serial.printf("[SPIFFS] Appended to %s\n", file_name);
}

// ==============================
// TIME HANDLING (like legacy)
// ==============================

static void startClock(const String &currentTimeString) {
    int y, mo, d, h, mi, s;
    // "YYYY-MM-DD HH:MM:SS"
    sscanf(currentTimeString.c_str(), "%d-%d-%d %d:%d:%d", &y, &mo, &d, &h, &mi, &s);

    setTime(h, mi, s, d, mo, y);   // TimeLib internal clock
    currentTime = now();

    Serial.print("[TIME] Current Time Set: ");
    Serial.println(currentTimeString);
}

static void parseMedicationTime(const String &timeString) {
    int h_alarm, m_alarm, h_offset, m_offset;
    char period[3] = {0};

    // Expect like "4:52 PM"
    sscanf(timeString.c_str(), "%d:%d %2s", &h_alarm, &m_alarm, period);

    Serial.print("[TIME] Medication Time Parsed: ");
    Serial.println(timeString);

    // Calculate hours offset to next occurrence
    if (h_alarm < hour() || (h_alarm == hour() && m_alarm <= minute())) {
        // passed already → schedule tomorrow
        h_offset = 24 - (hour() - h_alarm);
    } else {
        // later today
        h_offset = h_alarm - hour();
    }

    // Handle AM/PM adjustment similar to old code
    if (strcmp(period, "PM") == 0 && h_alarm < 12) {
        h_offset -= 12;   // this is imperfect, but kept consistent with legacy logic
    }

    // Minutes offset
    if (m_alarm < minute()) {
        m_offset = 60 - (minute() - m_alarm);
        h_offset -= 1;
    } else {
        m_offset = m_alarm - minute();
    }

    // Compute absolute reminder time
    reminderTime = now() + (h_offset * 60 * 60) + (m_offset * 60);
    reminderPending = true;

    Serial.print("[TIME] Medication Reminder set in (h:m) = ");
    Serial.print(h_offset);
    Serial.print(":");
    Serial.println(m_offset);
    Serial.print("[TIME] reminderTime (epoch) = ");
    Serial.println(reminderTime);
}

// ==============================
// STRING UTILITIES
// ==============================

static void splitOptions(const String &optionString, std::vector<String> &optionList) {
    optionList.clear();
    size_t start = 0;
    size_t end = 0;

    while ((end = optionString.indexOf(',', start)) != (size_t)-1) {
        String opt = optionString.substring(start, end);
        opt.trim();
        if (opt.length() > 0) optionList.push_back(opt);
        start = end + 1;
    }

    if (start < optionString.length()) {
        String opt = optionString.substring(start);
        opt.trim();
        if (opt.length() > 0) optionList.push_back(opt);
    }
}

// ==============================
// UI HELPERS
// ==============================

static void ui_show(const char *txt) {
    lv_obj_clean(lv_scr_act());
    ui_label = lv_label_create(lv_scr_act());
    lv_label_set_text(ui_label, txt);
    lv_obj_align(ui_label, LV_ALIGN_CENTER, 0, 0);
}

// Show a prompt + one highlighted option (auto-selected)
static void ui_prompt(const String &p, const String &opt) {
    lv_obj_clean(lv_scr_act());
    ui_label = lv_label_create(lv_scr_act());

    String txt = p + "\n\n< " + opt + " >";
    lv_label_set_text(ui_label, txt.c_str());
    lv_obj_align(ui_label, LV_ALIGN_CENTER, 0, 0);
}

// Graphic splash (Node logo + Capybara)
void ui_show_graphic_splash() {
    Serial.println("[UI] Showing graphic splash.");

    lv_obj_clean(lv_scr_act());

    // -------- NODE LOGO --------
    for (int i = 0; i < NODE_LOGO_WIDTH * NODE_LOGO_HEIGHT; i++) {
        node_buf[i].full = node_logo[i];
    }

    lv_obj_t *node_canvas = lv_canvas_create(lv_scr_act());
    lv_canvas_set_buffer(
        node_canvas,
        node_buf,
        NODE_LOGO_WIDTH,
        NODE_LOGO_HEIGHT,
        LV_IMG_CF_TRUE_COLOR
    );
    lv_obj_align(node_canvas, LV_ALIGN_TOP_MID, 0, 10);

    // -------- CAPYBARA --------
    for (int i = 0; i < CAPYBARA_FRAME1_WIDTH * CAPYBARA_FRAME1_HEIGHT; i++) {
        capy_buf[i].full = capybara_frame1[i];
    }

    lv_obj_t *capy_canvas = lv_canvas_create(lv_scr_act());
    lv_canvas_set_buffer(
        capy_canvas,
        capy_buf,
        CAPYBARA_FRAME1_WIDTH,
        CAPYBARA_FRAME1_HEIGHT,
        LV_IMG_CF_TRUE_COLOR
    );
    lv_obj_align(capy_canvas, LV_ALIGN_CENTER, 0, 40);

    Serial.println("[UI] Splash displayed.");
}


// ==================================
// "BUTTON" → TIMER (5 sec)
// ==================================
static int waitForNavigation() {
    Serial.println("[NAV] Auto-continue after 5 seconds (no buttons)");

    unsigned long start = millis();
    while (millis() - start < 5000) {
        lv_timer_handler();
        vTaskDelay(pdMS_TO_TICKS(10));
    }

    // 0 = ENTER in legacy
    return 0;
}

// ==============================
// Create test file
// ==============================

// Create a file for testing without Bluetooth
static void createTestFile() {
    File file = SPIFFS.open("/received.txt", "w");

    if (file) {
        file.print(
            "Current Time: 2025-02-11 16:51:35\n\n"
            "Medication: Methadone\n"
            "Dose: 100\n"
            "Frequency: Once daily\n"
            "Times: 4:51 PM\n"
            "Days: 1 to 5\n\n"
            
            "Prompt: stress?\n"
            "Required Response: Yes\n"
            "Options: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10\n"
            "Days: 1 to 5\n\n"
            
            "Prompt: opioids?\n"
            "Required Response: Yes\n"
            "Options: Yes, No\n"
            "Days: 1 to 5\n\n"
            
            "Prompt: momma?\n"
            "Required Response: Journal Response\n"
            "Options: Respond in Journal\n"
            "Days: 1 to 5\n"
        );

        file.close();
        Serial.println("File written successfully.");
    } else {
        Serial.println("Failed to create file for writing.");
    }
}

// ==============================
// Call Test File
// ==============================

static void ensureConfigFileExistsAndParse()
{
#if NODE_TEST_CONFIG_ON_BOOT
    if (!SPIFFS.exists("/received.txt")) {
        Serial.println("[TEST] /received.txt missing -> creating test config");
        createTestFile();  // writes /received.txt
    } else {
        Serial.println("[TEST] /received.txt exists -> NOT overwriting");
    }

    // Parse once at boot so reminderTime/prompts populate immediately
    parseFile("/received.txt");
#endif
}

// ==============================
// BLE SEND LOG FILE
// ==============================

static void sendLogFile(const char *filename) {
    if (!deviceConnected || !pCharacteristic) {
        Serial.println("[BLE] Not connected or characteristic null, cannot send log");
        return;
    }

    if (!SPIFFS.exists(filename)) {
        Serial.println("[BLE] No log file to send");
        return;
    }

    File file = SPIFFS.open(filename, "r");
    if (!file) {
        Serial.println("[BLE] Failed to open log file");
        return;
    }

    const size_t maxChunkSize = 512;
    char buffer[maxChunkSize + 1];

    Serial.println("[BLE] Sending log file contents:");

    while (file.available()) {
        size_t bytesRead = file.readBytes(buffer, maxChunkSize);
        buffer[bytesRead] = '\0';

        Serial.print(buffer);   // echo to Serial (optional)

        pCharacteristic->setValue((uint8_t *)buffer, bytesRead);
        pCharacteristic->notify();

        vTaskDelay(pdMS_TO_TICKS(50));
    }

    file.close();
    Serial.println("[BLE] Log file sent successfully");
}

// ==============================
// PARSE CONFIG FILE (received.txt)
// ==============================

static void parseFile(const char *name) {
    Serial.printf("[SPIFFS] Reading %s\n", name);

    prompts.clear();
    options.clear();
    medicationName = "";
    doseStr = "";
    frequencyStr = "";
    reminderTime = 0;
    reminderPending = false;

    File f = SPIFFS.open(name, "r");
    if (!f) {
        Serial.println("[SPIFFS] Failed to open config for parsing");
        return;
    }

    while (f.available()) {
        String line = f.readStringUntil('\n');
        line.trim();
        if (line.length() == 0) continue;

        // Header date from saveToFile is "Date: ..."
        if (line.startsWith("Current Time: ")) {
            // substring after "Current Time: "
            String ts = line.substring(14);
            ts.trim();
            startClock(ts);
        }
        else if (line.startsWith("Times: ")) {
            String ts = line.substring(7);
            ts.trim();
            parseMedicationTime(ts);
        }
        else if (line.startsWith("Medication: ")) {
            medicationName = line.substring(11);
            medicationName.trim();
            Serial.print("[PARSE] Medication: ");
            Serial.println(medicationName);
        }
        else if (line.startsWith("Dose: ")) {
            doseStr = line.substring(6);
            doseStr.trim();
            Serial.print("[PARSE] Dose: ");
            Serial.println(doseStr);
        }
        else if (line.startsWith("Frequency: ")) {
            frequencyStr = line.substring(11);
            frequencyStr.trim();
            Serial.print("[PARSE] Frequency: ");
            Serial.println(frequencyStr);
        }
        else if (line.startsWith("Prompt: ")) {
            String p = line.substring(8);
            p.trim();
            prompts.push_back(p);
            Serial.print("[PARSE] Prompt: ");
            Serial.println(p);
        }
        else if (line.startsWith("Options: ")) {
            String o = line.substring(9);
            o.trim();
            options.push_back(o);
            Serial.print("[PARSE] Options: ");
            Serial.println(o);
        }
        // "Days: ..." lines are ignored for now (same as legacy behavior)
    }

    f.close();

    // UI: show "Data Received / Reminder Armed." then return to Capybara
    ui_show("Data Received.\nReminder Armed.");
    Serial.println("[PARSE] Data received. Reminder armed.");

    // brief flash
    unsigned long start = millis();
    while (millis() - start < 3000) {
        lv_timer_handler();  //MAYBE I SHOULD GET RID OF THIS TO PREVENT DOUBLE CALLING
        vTaskDelay(pdMS_TO_TICKS(10));
    }

    // back to splash
    ui_show_graphic_splash();
}

// ==============================
// BLE CALLBACKS
// ==============================

class MyCallbacks : public BLECharacteristicCallbacks {
    void onWrite(BLECharacteristic *c) override {
        String value = c->getValue();
        if (value.length() == 0) return;

        Serial.print("[BLE RX] Chunk: ");
        Serial.println(value);

        incomingData += value;

        // Look for EOF marker indicating end of file
        if (incomingData.indexOf("EOF") != -1) {
            Serial.println("[BLE RX] Complete file received");
            Serial.println(incomingData);

            // Save full file and then parse it
            saveToFile(incomingData, "/received.txt");
            incomingData = "";

             // Mark ready for parsing in main loop
            configFileReady = true;
        }
    }
};

class MyServerCallbacks : public BLEServerCallbacks {
    void onConnect(BLEServer *s) override {
        deviceConnected = true;
        Serial.println("[BLE] Device connected");
    }

    void onDisconnect(BLEServer *s) override {
        deviceConnected = false;
        Serial.println("[BLE] Device disconnected");
        s->getAdvertising()->start();
    }
};


// ==============================
// LVGL Canas
// ==============================
void create_canvas() {
    if (canvas_ready) return;

    canvas_buf = (lv_color_t*) heap_caps_malloc(FRAME_W * FRAME_H * sizeof(lv_color_t), MALLOC_CAP_SPIRAM);

    if (!canvas_buf) {
        Serial.println("[ANIM] ERROR: Failed to allocate canvas buffer!");
        return;
    }
    
    canvas = lv_canvas_create(lv_scr_act());
    lv_canvas_set_buffer(canvas, canvas_buf, FRAME_W, FRAME_H , LV_IMG_CF_TRUE_COLOR);
    lv_obj_align(canvas, LV_ALIGN_CENTER, 0, 0);

    // Hide it so Capybara stays visible at boot
    lv_obj_add_flag(canvas, LV_OBJ_FLAG_HIDDEN);

    canvas_ready = true;
    Serial.println("[ANIM] Canvas created (hidden).");
}


bool load_raw_frame(const char *path, lv_color_t *dst, size_t size)
{
    File f = SD_MMC.open(path, "r");
    if (!f) {
        Serial.printf("[ANIM] ERROR: Could not open %s\n", path);
        return false;
    }

    size_t n = f.read((uint8_t*)dst, size);
    f.close();

    if (n != size) {
        Serial.printf("[ANIM] WARNING: Read %u bytes, expected %u (%s)\n",
                      n, size, path);
        return false;
    }

    return true;
}


void play_animal_animation()
{
    Serial.println("[ANIM] Creating animation canvas...");

    // 1) Clear screen once
    lv_obj_clean(lv_scr_act());

    // 2) Allocate once (PSRAM)
    canvas_buf = (lv_color_t*)heap_caps_malloc(
        FRAME_W * FRAME_H * sizeof(lv_color_t),
        MALLOC_CAP_SPIRAM
    );
    if (!canvas_buf) {
        Serial.println("[ANIM] ERROR: Failed to allocate canvas buffer");
        return;
    }

    // 3) Create canvas once
    canvas = lv_canvas_create(lv_scr_act());
    lv_canvas_set_buffer(canvas, canvas_buf, FRAME_W, FRAME_H, LV_IMG_CF_TRUE_COLOR);

    // 4) Set zoom once
    uint16_t zoom_x = (DISP_W * 256) / FRAME_W;
    uint16_t zoom_y = (DISP_H * 256) / FRAME_H;
    uint16_t zoom   = min(zoom_x, zoom_y);
    lv_img_set_zoom(canvas, zoom);
    lv_obj_align(canvas, LV_ALIGN_CENTER, 0, 40);

    // 5) Try fast packed file
    bool useFallback = false;
    File f = SD_MMC.open("/penguin_sleds/anim.bin", "r");
    if (!f) {
        Serial.println("[ANIM] ERROR: anim.bin not found. Falling back to per-frame files.");
        useFallback = true;
    }

    if (!useFallback) {
        // Sanity check size
        size_t expected = (size_t)FRAME_COUNT * (size_t)FRAME_SIZE;
        size_t actual   = (size_t)f.size();
        if (actual < expected) {
            Serial.printf("[ANIM] WARNING: anim.bin too small (%u < %u). Using available frames.\n",
                          (unsigned)actual, (unsigned)expected);
        }

        // Stable pacing
        const TickType_t frameTicks = pdMS_TO_TICKS(33); // 30fps
        TickType_t lastWake = xTaskGetTickCount();

        for (int i = 0; i < FRAME_COUNT; i++) {
            size_t n = f.read((uint8_t*)canvas_buf, FRAME_SIZE);
            if (n != FRAME_SIZE) {
                Serial.printf("[ANIM] End/short read at frame %d (read %u)\n", i, (unsigned)n);
                break;
            }

            lv_obj_invalidate(canvas);
            lv_timer_handler();
            vTaskDelayUntil(&lastWake, frameTicks);
        }

        f.close();
    } else {
        // ======= Slower fallback: per-frame files =======
        const TickType_t frameTicks = pdMS_TO_TICKS(33); // 30fps
        TickType_t lastWake = xTaskGetTickCount();

        char path[64];
        for (int i = 0; i < FRAME_COUNT; i++) {
            snprintf(path, sizeof(path), "/penguin_sleds/frame%03d.bin", i);

            File fr = SD_MMC.open(path, "r");
            if (!fr) {
                Serial.printf("[ANIM] Missing frame: %s\n", path);
                break;
            }

            size_t n = fr.read((uint8_t*)canvas_buf, FRAME_SIZE);
            fr.close();

            if (n != FRAME_SIZE) {
                Serial.printf("[ANIM] Short frame read %s (%u)\n", path, (unsigned)n);
                break;
            }

            lv_obj_invalidate(canvas);
            lv_timer_handler();
            vTaskDelayUntil(&lastWake, frameTicks);
        }
    }

    // 7) Cleanup
    if (canvas) {
        lv_obj_del(canvas);
        canvas = nullptr;
    }
    if (canvas_buf) {
        heap_caps_free(canvas_buf);
        canvas_buf = nullptr;
    }

    Serial.println("[ANIM] Animation finished");
}



// ==============================
// INITIALIZATION
// ==============================

void Node_Core_Init() {
    Serial.println("Node_Core_Init()");

    if (!SPIFFS.begin(true)) {
        Serial.println("[SPIFFS] Mount failed");
    } else {
        Serial.println("[SPIFFS] Mounted successfully");
    }

    // BLE setup
    BLEDevice::init("NODE");
    BLEServer *sv = BLEDevice::createServer();
    sv->setCallbacks(new MyServerCallbacks());

    BLEService *svc = sv->createService((uint16_t)0xFFE0);

    pCharacteristic = svc->createCharacteristic(
        (uint16_t)0xFFE1,
        BLECharacteristic::PROPERTY_WRITE | BLECharacteristic::PROPERTY_NOTIFY
    );
    pCharacteristic->setCallbacks(new MyCallbacks());
    pCharacteristic->addDescriptor(new BLE2902());

    svc->start();
    sv->getAdvertising()->start();

    // LVGL splash (Node + Capybara)
    ui_show_graphic_splash();

    ensureConfigFileExistsAndParse();

    Serial.println("[SYSTEM] Ready for BLE data.");

    Serial.println("[SYSTEM] Creating animation canvas...");
    Serial.println("[SYSTEM] Canvas ready.");
}


// ==============================
// MAIN LOOP
// ==============================

void Node_Core_Loop() {
    // This function should be called frequently from your main loop.
    // We do NOT call lv_timer_handler() here to avoid double-calls;
    // your main .ino should already be doing that regularly.

     // Handle new config file from BLE (safe context for LVGL)
    if (configFileReady) {
        configFileReady = false;
        parseFile("/received.txt");
    }

    if (reminderTime == 0) return;     // no reminder set yet
    if (!reminderPending) return;      // nothing armed

    time_t t = now();
    // Trigger when current time is within 60 seconds of reminderTime
    if (!inPromptFlow && t >= reminderTime && t < reminderTime + 60) {
        inPromptFlow = true;
        Serial.println("[REMINDER] Time to take meds!");

        // 1) Reminder screen (like legacy: "Time to take your meds...")
        ui_show("Time to take your meds!\nPress below to dispense.");
        waitForNavigation();           // 5-second timer instead of button

        // 2) Prompt flow
        String logEntry = "";

        for (size_t i = 0; i < prompts.size(); i++) {
            String p = prompts[i];

            // Parse options
            std::vector<String> optList;
            if (i < options.size()) {
                splitOptions(options[i], optList);
            }

            // AUTO: select first option (no buttons yet)
            String selectedOption = "No response";
            if (!optList.empty()) {
                selectedOption = optList[0];
            }

            Serial.print("[PROMPT] ");
            Serial.println(p);
            Serial.print("[SELECT] ");
            Serial.println(selectedOption);

            ui_prompt(p, selectedOption);
            waitForNavigation();   // 5-second view of this prompt

            logEntry += "Prompt: " + p + "  Response: " + selectedOption + "\n";
        }

        // 3) Save log (like legacy behavior)
        String medEntry = "Medication Taken: " +
                          String(hour()) + ":" +
                          String(minute()) + ":" +
                          String(second());

        Serial.println("[LOG] Medication + responses:");
        Serial.println(medEntry);
        Serial.print(logEntry);

        saveData(medEntry, "/log.txt");
        saveData(logEntry, "/log.txt");

        // 4) Send log back over BLE
        ui_show("Connecting to your phone...");
        sendLogFile("/log.txt");

        // Short thank-you screen
        ui_show("Thank you!");
        waitForNavigation();

        // -------------------------
        // PLAY ANIMAL ANIMATION
        // -------------------------
        Serial.println("[ANIM] Starting animal animation...");
        play_animal_animation();
        Serial.println("[ANIM] Animation complete.");
        // -------------------------

        // 5) Schedule reminder for same time tomorrow
        reminderTime += 86400;   // +24 hours
        Serial.print("[REMINDER] Next reminderTime epoch = ");
        Serial.println(reminderTime);

        // Back to splash
        ui_show_graphic_splash();

        inPromptFlow = false;
    }
}
